export type ElementKind = "video" | "image" | "text" | "audio" | "caption";
export type AnimationName = "fade" | "slide-up" | "zoom" | "none";

export interface EditableElement {
  id: string;
  kind: ElementKind;
  name: string;
  src?: string;
  text?: string;
  startFrame: number;
  durationInFrames: number;
  trackId: string;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  fontSize?: number;
  color?: string;
  animation?: AnimationName;
}

export interface Scene {
  id: string;
  name: string;
  startFrame: number;
  durationInFrames: number;
  elementIds: string[];
}

export interface Track {
  id: string;
  name: string;
  kind: ElementKind;
  order: number;
  muted?: boolean;
}

export interface StudioProject {
  schemaVersion: 1;
  id: string;
  title: string;
  width: number;
  height: number;
  fps: number;
  durationInFrames: number;
  scenes: Scene[];
  tracks: Track[];
  elements: EditableElement[];
}

export const starterProject: StudioProject = {
  schemaVersion: 1,
  id: "project-starter",
  title: "Untitled Project",
  width: 1920,
  height: 1080,
  fps: 30,
  durationInFrames: 540,
  scenes: [
    { id: "scene-1", name: "Opening scene", startFrame: 0, durationInFrames: 135, elementIds: ["title-1", "caption-1"] },
    { id: "scene-2", name: "Scene 2", startFrame: 135, durationInFrames: 135, elementIds: [] },
    { id: "scene-3", name: "Scene 3", startFrame: 270, durationInFrames: 135, elementIds: [] },
    { id: "scene-4", name: "Scene 4", startFrame: 405, durationInFrames: 135, elementIds: [] }
  ],
  tracks: [
    { id: "track-video", name: "VIDEO", kind: "video", order: 0 },
    { id: "track-text", name: "TEXT", kind: "text", order: 1 },
    { id: "track-audio", name: "AUDIO", kind: "audio", order: 2 }
  ],
  elements: [
    { id: "title-1", kind: "text", name: "Main title", text: "A story starts here", startFrame: 15, durationInFrames: 105, trackId: "track-text", fontSize: 78, color: "#ffffff", x: 960, y: 480, animation: "fade" },
    { id: "caption-1", kind: "caption", name: "Subtitle", text: "Select an element to edit it", startFrame: 25, durationInFrames: 95, trackId: "track-text", fontSize: 28, color: "#ded7e5", x: 960, y: 590, animation: "slide-up" }
  ]
};