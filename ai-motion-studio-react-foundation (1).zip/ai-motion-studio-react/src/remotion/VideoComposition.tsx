import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import type { StudioProject, EditableElement } from "../data/project";
import { theme } from "../theme";

const getOpacity = (frame: number, item: EditableElement) => {
  const local = frame - item.startFrame;
  if (item.animation === "fade") {
    return interpolate(local, [0, 18, item.durationInFrames - 8, item.durationInFrames], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  }
  return interpolate(local, [0, 8, item.durationInFrames], [0, 1, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
};

export const VideoComposition: React.FC<{ project: StudioProject }> = ({ project }) => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();
  const visible = project.elements.filter((item) => frame >= item.startFrame && frame < item.startFrame + item.durationInFrames);
  return (
    <AbsoluteFill style={{ background: "radial-gradient(ellipse at 50% 45%, #51415b 0%, #292234 48%, #16141c 100%)", color: theme.colors.text, fontFamily: theme.fonts.title }}>
      <AbsoluteFill style={{ borderTop: "4px solid #c9a76b", borderBottom: "4px solid #c9a76b", top: "4%", bottom: "4%", height: "92%", width: "88%", left: "6%" }} />
      {visible.map((item) => {
        const isText = item.kind === "text" || item.kind === "caption";
        const local = frame - item.startFrame;
        const opacity = getOpacity(frame, item);
        const translateY = item.animation === "slide-up" ? interpolate(local, [0, 18], [24, 0], { extrapolateRight: "clamp" }) : 0;
        const scale = item.animation === "zoom" ? interpolate(local, [0, 18], [0.85, 1], { extrapolateRight: "clamp" }) : 1;
        if (!isText) return null;
        return <div key={item.id} style={{ position: "absolute", left: `${((item.x ?? width / 2) / width) * 100}%`, top: `${((item.y ?? height / 2) / height) * 100}%`, transform: `translate(-50%, -50%) translateY(${translateY}px) scale(${scale})`, opacity, color: item.color ?? "#fff", fontSize: `${item.fontSize ?? 48}px`, fontWeight: item.kind === "text" ? 750 : 450, textAlign: "center", width: "85%", lineHeight: 1.2 }}>{item.text}</div>;
      })}
    </AbsoluteFill>
  );
};